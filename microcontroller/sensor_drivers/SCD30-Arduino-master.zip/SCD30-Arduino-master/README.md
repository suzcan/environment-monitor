# SCD30-Arduino
Arduino library for communication with Sensirion SCD30 CO2 sensor

Based off Adafruit's SGP30 library template. 
